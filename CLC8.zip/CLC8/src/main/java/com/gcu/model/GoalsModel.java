package com.gcu.model;

/**
 * The Class GoalsModel.
 * We decided not to use this class
 */
public class GoalsModel {

	/** The Strength. */
	private int Strength;
	
	/** The Endurace. */
	private int Endurace;
	
	/** The Weight. */
	private int Weight;
	
	/**
	 * Gets the strength.
	 *
	 * @return the strength
	 */
	public int getStrength() {
		return Strength;
	}
	
	/**
	 * Sets the strength.
	 *
	 * @param strength the new strength
	 */
	public void setStrength(int strength) {
		Strength = strength;
	}
	
	/**
	 * Gets the endurace.
	 *
	 * @return the endurace
	 */
	public int getEndurace() {
		return Endurace;
	}
	
	/**
	 * Sets the endurace.
	 *
	 * @param endurace the new endurace
	 */
	public void setEndurace(int endurace) {
		Endurace = endurace;
	}
	
	/**
	 * Gets the weight.
	 *
	 * @return the weight
	 */
	public int getWeight() {
		return Weight;
	}
	
	/**
	 * Sets the weight.
	 *
	 * @param weight the new weight
	 */
	public void setWeight(int weight) {
		Weight = weight;
	}
}
